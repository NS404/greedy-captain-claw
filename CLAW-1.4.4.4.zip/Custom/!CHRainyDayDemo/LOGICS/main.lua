function OnMapLoad()
	CreateObject {x=GetClaw().X, y=GetClaw().Y, z=9000, logic="CustomLogic", name="RainCloud"}
	TextOut("Zax37 was here \n\n Kisses for Kubus_PL :*")
	BnW()
end
